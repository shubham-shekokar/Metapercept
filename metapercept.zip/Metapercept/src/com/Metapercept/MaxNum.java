package com.Metapercept;

public class MaxNum {

	public static void main(String[] args) {
		Object[] jaggedArray = {2,4,10,new Object[] {12,4,new Object[] {100,99},4},new Object[] {3,2,99},0};
		
		int maxNum = findMaxNum(jaggedArray);
		System.out.println("Max Number: " + maxNum);
	}
	
	public static int findMaxNum(Object[] jaggedArray) {
		int maxNum = Integer.MIN_VALUE;
		
		for(Object element : jaggedArray) {
			if(element instanceof Integer) {
				int number = (int) element;
				if(number > maxNum) {
					maxNum = number;
				}
			}
			else if(element instanceof Object[]){
				int subArrayMax = findMaxNum((Object[]) element);
				if(subArrayMax > maxNum) {
					maxNum = subArrayMax;
				}
			}
		}
		return maxNum;
	}

}
