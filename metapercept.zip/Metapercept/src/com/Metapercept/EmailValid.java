package com.Metapercept;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.crypto.dsig.dom.DOMValidateContext;

public class EmailValid {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter email ");
		String str = sc.nextLine();
		
		boolean isValid = validateEmail(str);
		
		if(isValid) {
			System.out.println("Valid email id");
		}else {
			System.out.println("Invalid email id");
		}
		
	}
	
	public static boolean validateEmail(String str) {
		String emailRegex = "^[a-zA-Z0-9_+.-]+@[a-zA-Z0-9.-]+$";
		Pattern pattern = Pattern.compile(emailRegex);
		Matcher matcher = pattern.matcher(str);
		return matcher.matches();
	}

}
