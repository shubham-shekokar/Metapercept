package com.Metapercept;

import java.util.Scanner;

public class LongWord {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string: ");
		String str = sc.nextLine();
		
		str = str + " ";
		String word = "";
		String lg = "";
		for(int i=0; i<str.length(); i++) {
			char ch = str.charAt(i);
			
			if(ch != ' ') {
				word = word + ch;
			}
			else {
				if(word.length()>lg.length()) {
					lg = word;
				}
				word = "";
				
			}
		}
		System.out.println("Longest word is: " + lg);

	}

}
